import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from 'src/app/shared/services/validation/validation.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  formGroup: FormGroup;
  constructor(private fb: FormBuilder,
    private route: Router,
    private validationService:ValidationService,) { }

  ngOnInit(): void {
    this.formGroup = this.fb.group({
      email: ['', [Validators.email, Validators.required]],
      password: ['',  Validators.required],
      gender: ['',  Validators.required],
      fname: ['',  Validators.required],
      lname: ['',  Validators.required],
      title: ['',  Validators.required],
      username: ['',  Validators.required],
      phone: ['', Validators.required],
      dob: ['',  Validators.required],
    });
  }

  registrationHandler(){
    if(this.formGroup.status == 'VALID'){
    let validationResult=this.validationService.registrationHandler(this.formGroup.value);
    if(validationResult){
      alert('Registered successfully')
    }
    }else{
      alert('please enter value to all the fields')
    }
  }

  loginHandler(){
    this.route.navigateByUrl('login')
  }

}
