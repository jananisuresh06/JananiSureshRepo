import { Input, Component, Output, EventEmitter,OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiConnectionService } from 'src/app/shared/services/api-connection/api-connection.service';
import { ValidationService } from 'src/app/shared/services/validation/validation.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email:string='';
  password:string='';
  formGroup: FormGroup;

  constructor(private fb: FormBuilder,
              private validationService:ValidationService,
              private route: Router,
              private apiconnectionService:ApiConnectionService) { }

  ngOnInit() {
    this.formGroup = this.fb.group({
      email: ['', [Validators.email, Validators.required]],
      password: ['',  Validators.required]
    });
  }
  
  loginHandler(){
    if(this.formGroup.status == 'VALID'){
      this.apiconnectionService.getAllUsers().subscribe((result)=>{
        let validationResult=this.validationService.handleLoginValidation(this.formGroup.value,result);
        if(validationResult.allowRoute){
          let name=(validationResult.user.name.first+" ").concat(validationResult.user.name.last);
          validationResult.user.name=(validationResult.user.name.title+". ").concat(name);
          this.validationService.currentUser=validationResult.user
          this.route.navigateByUrl("home")
        }
        else{
          alert(validationResult.message);
        }
      })
    }
    else{
      alert('Please enter proper credentials');
    }
  }

  registrationHandler(){
    this.route.navigateByUrl('newUser')
  }
  
}
