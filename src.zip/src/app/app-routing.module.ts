import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/components/login/login.component';
import { RegistrationComponent } from './login/components/registration/registration.component';

const routes: Routes = [{ path:  'login', component: LoginComponent },
{ path:  'newUser', component:RegistrationComponent},
{ path:  'home', loadChildren:'./home/components/home/home.component'},
{path: '', redirectTo: 'login', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
