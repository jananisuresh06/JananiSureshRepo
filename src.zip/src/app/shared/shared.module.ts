import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiConnectionService } from './services/api-connection/api-connection.service';
import { ValidationService } from './services/validation/validation.service';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers:[ApiConnectionService,ValidationService]
})
export class SharedModule { }
