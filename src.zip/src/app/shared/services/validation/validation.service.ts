import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ValidationService {

  currentUser: any;
  storageMonitor= new Subject<String>();
  constructor() { }
  handleLoginValidation(credentialJSON, userListArray): any {
    let result;
    userListArray = userListArray.results;
    let flag = 8;
    for (let userIndex = 0; userIndex < userListArray.length; userIndex++) {
      if (userListArray[userIndex].user.email == credentialJSON.email && userListArray[userIndex].user.password == credentialJSON.password && flag == 8) {
        result = {
          message: 'valid',
          allowRoute: true,
          user: userListArray[userIndex].user
        };
        return result
      }
      else if (userListArray[userIndex].user.email == credentialJSON.email && userListArray[userIndex].user.password != credentialJSON.password && flag == 8) {
        result = {
          message: 'Please enter valid password',
          allowRoute: false
        };
        return result;
      }
      else{
        var isLocalStorageValue=JSON.parse(localStorage.getItem(credentialJSON.email));
        if(isLocalStorageValue){
          result = {
            message: 'valid',
            allowRoute: true,
            user: userListArray[userIndex].user
          };
          this.currentUser=isLocalStorageValue;
          return result
        }
        else{
          result = {
            message: "Your email doesn't match. Are you a new user? Please register",
            allowRoute: false
          }
        }
      }      
    }
    return result
  }

  registrationHandler(userDetailJson){
    let newlyEnteredValue={
      email: userDetailJson.email,
      password: userDetailJson.password,
      gender: userDetailJson.gender,
      name:{
      first: userDetailJson.fname,
      last: userDetailJson.lname,
      title: userDetailJson.title
      },
      username: userDetailJson.username,
      phone: userDetailJson.phone,
      dob:userDetailJson.dob,
    };
    this.currentUser=newlyEnteredValue;
    localStorage.setItem(newlyEnteredValue.email,JSON.stringify(newlyEnteredValue));
    return 'success'
  }
}
