import { Component, Input, OnInit } from '@angular/core';
import { ApiConnectionService } from 'src/app/shared/services/api-connection/api-connection.service';

@Component({
  selector: 'app-listing-user',
  templateUrl: './listing-user.component.html',
  styleUrls: ['./listing-user.component.css']
})
export class ListingUserComponent implements OnInit {

  @Input() userList;
  @Input() currentUser;
  constructor(private apiService:ApiConnectionService) { }

  ngOnInit(): void {
  }

}
