import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ValidationService } from 'src/app/shared/services/validation/validation.service';
import { ApiConnectionService } from '../../../shared/services/api-connection/api-connection.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  userList:any;
  constructor(public apiService:ApiConnectionService,
              public validationService:ValidationService,
              private route: Router,) { }

  ngOnInit(): void {
    this.getAllUser();
  }

  getAllUser(){
    this.apiService.getAllUsers().subscribe((result)=>{
      this.userList=result;
      this.userDataFormatter();
    })
  }

  userDataFormatter(){
    this.userList=this.userList.results;
    for(let userIndex=0;userIndex<this.userList.length;userIndex++){
      let name=(this.userList[userIndex].user.name.first+" ").concat(this.userList[userIndex].user.name.last);
      this.userList[userIndex].user.name=(this.userList[userIndex].user.name.title+". ").concat(name);
    }
  }

  logout(){
    localStorage.removeItem("userList");
    this.route.navigateByUrl("login");
  }

}