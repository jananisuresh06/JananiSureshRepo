import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './components/home/home.component';
import { ListingUserComponent } from './components/listing-user/listing-user.component';
import { SharedModule } from '../shared/shared.module';



@NgModule({
  declarations: [HomeComponent, ListingUserComponent],
  imports: [
    CommonModule,
    SharedModule
  ]
})
export class HomeModule { }
